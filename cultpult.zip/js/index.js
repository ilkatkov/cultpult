// try {
$(document).ready(function() {
    $("#modal_android").fancybox().trigger('click');
});
// } catch (error) {}