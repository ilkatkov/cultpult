<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Заполнение базы данных КультПульт</title>
    <style>
        a {
            color: black;
        }
    </style>
</head>

<body>
    <h3>Заполнение базы данных КультПульт</h3>
    <p>♥<a href = "add_participant.php">Добавить студента</a></p>
    <p>♥<a href = "add_event.php">Добавить группу</a></p>
</body>

</html>